# full-model-all-stars
Website aimed at providing children of all ages with an accessible platform to become familiar with a local sports programme.
The local sports programme in question is the "All Stars Programme" which is being run by a small group of volunteers from Bearna Na bhForbacha Hurling club in County Galway,Ireland.The programme looks to give children with additional needs the opportunity to take part in organised sports.
Website is designed with simplicity in mind,a fact which has been proven to make a website more accessible and usable to people with additional needs. Website's main purpose is to showcase the environment in which the children would be playing the sports in i.e: the local pitch. 
There is a video that shows some children going through the various drills and activities.
Children with additional needs are averse to sudden change but when given plenty of advance notice they can prepare and therefore deal with the change much better.
Therefore this website aims to introduce the people and environment that a child would be engaging with at an "All Stars" session. 
